//
//  DataAlphabet.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio,  Salas Pineda Ricardo. All rights reserved.
//

import Foundation
import UIKit

struct LetterData {
    var nombre: String
    var imagen: UIImage
}

struct NumberData {
    var number: String
    var numimage: UIImage
}

struct MonthData {
    var monthname: String
    var monthimage: UIImage
}

struct DaysData {
    var Dayname: String
    var Dayimage: UIImage
}
