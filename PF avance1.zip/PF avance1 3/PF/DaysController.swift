//
//  DaysController.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio, Salas Pineda Ricardo. All rights reserved.
//

import UIKit

class DaysController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var TABLEDAYS: UITableView!
    var days = [DaysData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        days.append(DaysData(Dayname: "Lunes", Dayimage: UIImage(named: "Lunes")!))
        days.append(DaysData(Dayname: "Martes", Dayimage: UIImage(named: "Martes")!))
        days.append(DaysData(Dayname: "Miércoles", Dayimage: UIImage(named: "Miercoles")!))
        days.append(DaysData(Dayname: "Jueves", Dayimage: UIImage(named: "Jueves")!))
        days.append(DaysData(Dayname: "Viernes", Dayimage: UIImage(named: "Viernes")!))
        days.append(DaysData(Dayname: "Sábado", Dayimage: UIImage(named: "Sabado")!))
        days.append(DaysData(Dayname: "Domingo", Dayimage: UIImage(named: "Domingo")!))

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return days.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DAY", for: indexPath)
        
        cell.textLabel?.text = "\(days[indexPath.row].Dayname)"
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SELECTEDDAY" {
            
            let indexPath = TABLEDAYS.indexPathForSelectedRow
            let destination = segue.destination as! DaysViewController
            
            destination.Days = days[(indexPath?.row)!]
            
        }
    }
}
