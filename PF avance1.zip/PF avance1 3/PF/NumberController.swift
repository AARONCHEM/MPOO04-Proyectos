//
//  NumberController.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio, Salas Pineda Ricardo. All rights reserved.
//

import UIKit

class NumberController: UIViewController, UITableViewDataSource {
    
    
    @IBOutlet weak var TABLENUM: UITableView!
    var Numbers = [NumberData]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Numbers.append(NumberData(number: "1", numimage: UIImage(named: "01")!))
        Numbers.append(NumberData(number: "2", numimage: UIImage(named: "02")!))
        Numbers.append(NumberData(number: "3", numimage: UIImage(named: "03")!))
        Numbers.append(NumberData(number: "4", numimage: UIImage(named: "04")!))
        Numbers.append(NumberData(number: "5", numimage: UIImage(named: "05")!))
        Numbers.append(NumberData(number: "6", numimage: UIImage(named: "06")!))
        Numbers.append(NumberData(number: "7", numimage: UIImage(named: "07")!))
        Numbers.append(NumberData(number: "8", numimage: UIImage(named: "08")!))
        Numbers.append(NumberData(number: "9", numimage: UIImage(named: "09")!))
        Numbers.append(NumberData(number: "10", numimage: UIImage(named: "10")!))
        Numbers.append(NumberData(number: "11", numimage: UIImage(named: "11")!))
        Numbers.append(NumberData(number: "12", numimage: UIImage(named: "12")!))
        Numbers.append(NumberData(number: "13", numimage: UIImage(named: "13")!))
        Numbers.append(NumberData(number: "14", numimage: UIImage(named: "14")!))
        Numbers.append(NumberData(number: "15", numimage: UIImage(named: "15")!))
        Numbers.append(NumberData(number: "16", numimage: UIImage(named: "16")!))
        Numbers.append(NumberData(number: "17", numimage: UIImage(named: "17")!))
        Numbers.append(NumberData(number: "18", numimage: UIImage(named: "18")!))
        Numbers.append(NumberData(number: "19", numimage: UIImage(named: "19")!))
        Numbers.append(NumberData(number: "20", numimage: UIImage(named: "20")!))
        Numbers.append(NumberData(number: "30", numimage: UIImage(named: "30")!))
        Numbers.append(NumberData(number: "40", numimage: UIImage(named: "40")!))
        Numbers.append(NumberData(number: "50", numimage: UIImage(named: "50")!))
        Numbers.append(NumberData(number: "60", numimage: UIImage(named: "60")!))
        Numbers.append(NumberData(number: "70", numimage: UIImage(named: "70")!))
        Numbers.append(NumberData(number: "80", numimage: UIImage(named: "80")!))
        Numbers.append(NumberData(number: "90", numimage: UIImage(named: "90")!))
        Numbers.append(NumberData(number: "100", numimage: UIImage(named: "100")!))
        Numbers.append(NumberData(number: "200", numimage: UIImage(named: "200")!))
        Numbers.append(NumberData(number: "300", numimage: UIImage(named: "300")!))
        Numbers.append(NumberData(number: "400", numimage: UIImage(named: "400")!))
        Numbers.append(NumberData(number: "500", numimage: UIImage(named: "500")!))
        Numbers.append(NumberData(number: "600", numimage: UIImage(named: "600")!))
        Numbers.append(NumberData(number: "700", numimage: UIImage(named: "700")!))
        Numbers.append(NumberData(number: "800", numimage: UIImage(named: "800")!))
        Numbers.append(NumberData(number: "900", numimage: UIImage(named: "900")!))
        Numbers.append(NumberData(number: "1000", numimage: UIImage(named: "1000")!))

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Numbers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NUMBER", for: indexPath)
        
        cell.textLabel?.text = "\(Numbers[indexPath.row].number)"
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "SELECT" {
            
            let indexPath = TABLENUM.indexPathForSelectedRow
            let destination = segue.destination as! NumberViewController
            
            destination.NUMBER = Numbers[(indexPath?.row)!]
        }
    }
}
