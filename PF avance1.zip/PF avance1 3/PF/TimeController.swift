//
//  TimeController.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio, Salas Pineda Ricardo. All rights reserved.
//

import UIKit

class TimeController: UIViewController {

    @IBOutlet weak var DAYS: UIButton!
    @IBOutlet weak var MONTHS: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MONTHS.layer.cornerRadius = 10
        DAYS.layer.cornerRadius = 10

    }

}
