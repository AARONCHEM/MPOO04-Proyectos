//
//  MonthViewController.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio, Salas Pineda Ricardo. All rights reserved.
//

import UIKit

class MonthViewController: UIViewController {

    @IBOutlet weak var MONTHIMAGE: UIImageView!
    @IBOutlet weak var MONTHNAME: UILabel!
    var Months: MonthData!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     MONTHNAME.text = Months.monthname
     MONTHIMAGE.image = Months.monthimage

    }
}
